The files with "wastral" in the file names are the inferred species trees.

The files with "sponges" or "ctenohpres" in the file names are the alternative hypothesis created in Mesquite

See Supplementary Methods for more details.
